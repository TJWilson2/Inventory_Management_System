﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventory_Management_System
{
    class Variables
    {
        public static bool loginSuccess = false;
        public static bool adminLoggedIn = false;
        public static string currentLoggedInUser = "";
        public static string userSelectedDate = "";
    }
}
